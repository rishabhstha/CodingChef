from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import os
import time
import pandas as pd
import math
import numpy as np

csv = pd.read_excel('ingData.xlsx')
new_csv = csv[["Shrt_Desc", "Energ_Kcal", "GmWt_Desc1", "GmWt_Desc2"]]
new_csv["Energ_Kcal"] = new_csv["Energ_Kcal"]/100
new_csv = new_csv.values

x = new_csv[:,0]

substrings = [line.rstrip('\n') for line in open("remove.txt")]
for substring in substrings: 

    finder = np.frompyfunc(lambda z: substring in z,1,1)
    indices = np.where(finder(x))
    new_csv = np.delete(new_csv, indices, axis=0)

oneTwo = [line.rstrip('\n') for line in open("1-2-Ingredients.txt")]
moreTwo = [line.rstrip('\n') for line in open("2-gt-Ingredients.txt")]
for i in range(len(oneTwo)):
    if(oneTwo[i]!='0'):
        new_csv[i,0] = oneTwo[i]
    else:
        new_csv[i,0] = '0'
        
for i in range(len(moreTwo)):
    if(moreTwo[i]!='0'):
        new_csv[i,0] = moreTwo[i]
        
finder = np.frompyfunc(lambda x: "0" == x,1,1)
new_csv = np.delete(new_csv,np.where(finder(new_csv[:,0])),axis=0)
new_csv[:,2] = [str(x) for x in new_csv[:,2]]
new_csv[:,3] = [str(x) for x in new_csv[:,3]]

measures = [line.rstrip('\n') for line in open("measures.txt")]
measures = [x.split(",") for x in measures]
mgroups = {}
for sublist in measures:
    mgroups[sublist[0]] = sublist[1:len(sublist)]
measures = [x for sublist in measures for x in sublist]

for i in range(len(new_csv[:,2])):
    for j in measures:
        if j in new_csv[i,2]:
            new_csv[i,2] = j
            
for i in range(len(new_csv[:,3])):
    for j in measures:
        if j in new_csv[i,3]:
            new_csv[i,3] = j
            
for i in range(len(new_csv[:,2])):
    for j in measures[37:44]:
        if j in new_csv[i,2]:
            new_csv[i,2] = "serving"
            
for i in range(len(new_csv[:,3])):
    for j in measures[37:44]:
        if j in new_csv[i,3]:
            new_csv[i,3] = "serving"

for i in range(len(new_csv[:,2])):
    if new_csv[i,2] == "nan" and new_csv[i,3] != "nan":
        new_csv[i,2] = new_csv[i,3]
    elif new_csv[i,3] == "nan" and new_csv[i,2] != "nan":
        new_csv[i,3] = new_csv[i,2]
        
for i in range(len(new_csv[:,2])):
    if new_csv[i,2] == '"':
        new_csv[i,2] = "inch"
    if new_csv[i,3] == '"':
        new_csv[i,3] = "inch"
        
matcher = np.frompyfunc(lambda x: not any(i in x for i in measures),1,1)
for i in np.where(matcher(new_csv[:,2]))[0]:
    new_csv[i,2] = "serving"
for i in np.where(matcher(new_csv[:,3]))[0]:
    new_csv[i,3] = "serving"
    
for i in range(len(new_csv[:,2])):
    for k in mgroups:
        if new_csv[i,2] in mgroups[k]:
            new_csv[i,2] = k
        if new_csv[i,3] in mgroups[k]:
            new_csv[i,3] = k

for i in range(len(new_csv[:,2])):
    if new_csv[i,2] == "Unique" and new_csv[i,3] != "Unique":
        new_csv[i,2] = new_csv[i,3]
    if new_csv[i,3] == "Unique" and new_csv[i,2] != "Unique":
        new_csv[i,3] = new_csv[i,2]

for i in range(len(new_csv[:,2])):
    if new_csv[i,2] == "Length" and new_csv[i,3] == "Volume":
        new_csv[i,2] = new_csv[i,3]
    if new_csv[i,2] == "Volume":
        new_csv[i,3] = new_csv[i,2]
    if new_csv[i,3] == "Volume":
        new_csv[i,2] = new_csv[i,3]
    if new_csv[i,2] == "Mass and Weight" and new_csv[i,3] == "Length":
        new_csv[i,2] = "Unique"
        new_csv[i,3] = "Unique"
    if new_csv[i,2] == "Length" and new_csv[i,3] == "Mass and Weight":
        new_csv[i,2] = "Unique"
        new_csv[i,3] = "Unique"
        
prices = np.repeat(0,len(new_csv[:,0]), axis=0)
new_csv = np.column_stack((new_csv, prices))

def amazon_scrape(new_csv, missing=False):
    chrome_options = Options()
    chrome_options.add_argument("--headless")
    chrome_options.add_argument("--window-size=1920x1080")
    chrome_options.add_argument('--ignore-certificate-errors')
    chrome_driver = os.getcwd() + "\\chromedriver.exe"
    driver = webdriver.Chrome(chrome_options=chrome_options, executable_path=chrome_driver)
    
    url_prefix = "https://www.amazon.com/s?k="
    url_suffix = "&i=amazonfresh&ref=nb_sb_noss"
    
    tm = 1
    if missing:
        tm = 2
    
    for i in range(len(new_csv)):
        if new_csv[i,4] != 0:
            continue
        time.sleep(tm)
        #Get ingredient name
        ingredientName = '+'.join(new_csv[i,0].split(" ")).lower()
        
        #Load Page
        driver.get(url_prefix+ingredientName+url_suffix)
            
        if "No results" in driver.page_source:
            continue
        else:
            #Get unit costs
            unitCosts = driver.find_elements_by_xpath("//span[@class='a-size-base a-color-secondary']")
            if len(unitCosts) > 3:
                unitCosts = unitCosts[:3]
            if len([i.text for i in unitCosts if '$' in i.text]) == 0:
                continue
            else:
                #Store a list of the unit costs
                unitCosts = [i.text for i in unitCosts if '$' in i.text]
                new_csv[i,4] = unitCosts
    
    driver.quit()
    return new_csv

new_csv = amazon_scrape(new_csv)

finder = np.frompyfunc(lambda x: x == 0,1,1)
indices_of_missing_ingredients = np.where(finder(new_csv[:,4]))[0]
hardcoded_costs = [line.rstrip('\n').split(',')[1] for line in open("hardCodePrices.csv")]
hardcoded_names = np.array([line.rstrip('\n').split(',')[0] for line in open("hardCodePrices.csv")])

for i in indices_of_missing_ingredients:
    name_to_find = new_csv[i,0]
    index = np.where(hardcoded_names == name_to_find)[0]
    if len(index) == 0:
        continue
    missing_cost = hardcoded_costs[index[0]]
    new_csv[i,4] = np.repeat(missing_cost,3).tolist()

singletons = np.frompyfunc(lambda x: len(x) != 3,1,1)
less_than_three_entries = np.where(singletons(new_csv[:,4]))[0]
for i in less_than_three_entries:
    new_csv[i,4] = np.repeat(new_csv[i,4][0], 3).tolist()

for i in range(len(new_csv[:,4])):
    measures = [x.strip(')').split("/")[1] for x in new_csv[i,4]]
    for j in range(len(measures)):
        if measures[j] == "Count" or measures[j] == "Item":
            new_csv[i,4][j] = 0
    new_csv[i,4] = [x for x in new_csv[i,4] if x != 0]
    
finder = np.frompyfunc(lambda x: len(x) == 0,1,1)
indices_of_missing_ingredients = np.where(finder(new_csv[:,4]))[0]

for i in indices_of_missing_ingredients:
    name_to_find = new_csv[i,0]
    index = np.where(hardcoded_names == name_to_find)[0]
    if len(index) == 0:
        continue
    missing_cost = hardcoded_costs[index[0]]
    new_csv[i,4] = np.repeat(missing_cost,3).tolist()
    

conversions = {
    '100 g': 100,
    'Fl Oz': 29.57,
    'Ounce': 28.35,
    'kg': 1000,
    'Kilogram': 1000,
    'lb': 453.59,
    'oz': 28.35}        

for i in range(len(new_csv[:,4])):
    item_price = 0
    for j in range(len(new_csv[i,4])):
        values = new_csv[i,4][j].strip('()$').split('/')
        values[0] = float(values[0])
        values[1] = conversions[values[1]]
        item_price += values[0]/values[1]
    new_csv[i,4] = round(item_price/len(new_csv[i,4]),3)
    
for i in range(len(new_csv[:,0])):
    new_csv[i,0] = new_csv[i,0].title()
    
for i in range(len(new_csv[:,4])):
    if math.isclose(new_csv[i,4],0.0):
        new_csv[i,4] = 0.001

new_csv = np.delete(new_csv,3,1)

for i in range(len(new_csv[:,2])):
    if(new_csv[i,2] == "Length"):
        new_csv[i,2] = "Unique"