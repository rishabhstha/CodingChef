from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
import os
import time
import numpy as np

chrome_options = Options()
chrome_options.add_argument("--headless")
chrome_options.add_argument("--window-size=1920x1080")
chrome_options.add_argument('--ignore-certificate-errors')
chrome_driver = os.getcwd() + "\\chromedriver.exe"
driver = webdriver.Chrome(chrome_options=chrome_options, executable_path=chrome_driver)

url_prefix = "https://www.amazon.com/s?k="
url_suffix = "&i=amazonfresh&ref=nb_sb_noss"

for i in range(len(new_csv)):
    time.sleep(1)
    #Get ingredient name
    ingredientName = '+'.join(new_csv[i,0].split(" ")).lower()
    
    #Load Page
    driver.get(url_prefix+ingredientName+url_suffix)
        
    if "No results" in driver.page_source:
        continue
    else:
        #Get unit costs
        unitCosts = driver.find_elements_by_xpath("//span[@class='a-size-base a-color-secondary']")
        if len(unitCosts) > 3:
            unitCosts = unitCosts[:3]
        if len([i.text for i in unitCosts if '$' in i.text]) == 0:
            continue
        else:
            #Store a list of the unit costs
            unitCosts = [i.text for i in unitCosts if '$' in i.text]
            new_csv[i,4] = unitCosts

driver.quit()