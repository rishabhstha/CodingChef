import mysql.connector 

measures = [line.rstrip('\n') for line in open("measuresAndGroups.txt")]
measures = [x.split(",") for x in measures]
measurementGroups = [x[0] for x in measures]
measures = [x[1:len(x)] for x in measures]
measures = [x for x in measures if len(x) != 0]
measures = [[i.split('-') for i in x] for x in measures]
weights = [[i[1] for i in x] for x in measures]
measures = [[i[0] for i in x] for x in measures]
measures = [x for sublist in measures for x in sublist]
weights = [float(x) for sublist in weights for x in sublist]
measure_records = [(measures[i],weights[i]) for i in range(len(measures))]
ingredients = [line.rstrip('\n').split(',') for line in open("completeData.csv")]
for i in range(len(ingredients)):
    placeholder = float(ingredients[i][1])
    ingredients[i][1] = measurementGroups.index(ingredients[i][2])+1
    ingredients[i][2] = placeholder
    ingredients[i][3] = float(ingredients[i][3])
    
ingredients = [tuple(x) for x in ingredients]
measurementGroups = [tuple([x]) for x in measurementGroups]
mgc = [tuple([1,i+1]) for i in range(9)]
for i in range(9,14):
    mgc.append(tuple([2,i+1]))
for i in range(14):
    mgc.append(tuple([3,i+1]))

records_to_insert = [measurementGroups,measure_records,ingredients, mgc]
                     
insertQueries = ["INSERT INTO MeasurementGroup (measurementGroupName) VALUES (%s)",
                    "INSERT INTO Measurement (measurementName, weightInGrams) VALUES (%s, %s)",
                    "INSERT INTO Ingredient (ingredientName, measurementGroupID, caloriesPerGram, costPerGram) VALUES (%s, %s, %s, %s)",
                    "INSERT INTO MeasurementGroupContents (measurementGroupID, measurementID) VALUES (%s, %s)"]

connection = mysql.connector.connect(user="nnchawla@cooking-chef",
password="sd&d387!", host="cooking-chef.mysql.database.azure.com",
port=3306, database="cooking_chef", 
ssl_ca="C:\\Users\\Nayan Chawla\\Downloads\\ingredientsData\\BaltimoreCyberTrustRoot.crt.pem", ssl_verify_cert=True)

for i in range(len(insertQueries)):
    try:        
        query = insertQueries[i]
        records = records_to_insert[i]

        cursor = connection.cursor()
        cursor.executemany(query, records)
        connection.commit()
        print(cursor.rowcount, "Record inserted successfully into table")

    except mysql.connector.Error as error:
        print("Failed to insert record into MySQL table {}".format(error))
        print(query)

if (connection.is_connected()):
    cursor.close()
    connection.close()
    print("MySQL connection is closed")
        
