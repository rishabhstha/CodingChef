DROP database cooking_chef;
CREATE database cooking_chef;
USE cooking_chef;

CREATE TABLE Usr (
    userID int NOT NULL AUTO_INCREMENT,
    username varchar(20),
    userPassword varchar(20),
    adminStatus boolean,
    PRIMARY KEY (userID)
);

CREATE TABLE Recipe (
    recipeID int NOT NULL AUTO_INCREMENT,
    recipePhotoURL varchar(2083),
    recipeName varchar(20),
    recipePrivate boolean,
    recipeDirections TEXT,
    servingSize DECIMAL(11,1),
    creatorID int NOT NULL,
    prepTime TIME,
    PRIMARY KEY (recipeID),
    FOREIGN KEY (creatorID) REFERENCES Usr(userID)
);

CREATE TABLE Meal (
    userID int NOT NULL,
    recipeID int NOT NULL,
    startTime DATETIME,
    endTime DATETIME,
    FOREIGN KEY (userID) REFERENCES Usr(userID),
    FOREIGN KEY (recipeID) REFERENCES Recipe(recipeID),
    PRIMARY KEY (userID, recipeID)
);

CREATE TABLE RecipeSpec (
    recipeID int NOT NULL,
    recipeCost decimal(11,2),
    recipeCalories int,
    FOREIGN KEY (recipeID) REFERENCES Recipe(recipeID),
    PRIMARY KEY (recipeID)
);

CREATE TABLE Favorite (
    userID int NOT NULL,
    recipeID int NOT NULL,
    FOREIGN KEY (userID) REFERENCES Usr(userID),
    FOREIGN KEY (recipeID) REFERENCES Recipe(recipeID),
    PRIMARY KEY (userID, recipeID)
);

CREATE TABLE MeasurementGroup (
    measurementGroupID int NOT NULL AUTO_INCREMENT,
    measurementGroupName varchar(20),
    PRIMARY KEY (measurementGroupID)
);

CREATE TABLE Measurement (
    measurementID int NOT NULL AUTO_INCREMENT,
    measurementName varchar(20),
    weightInGrams DECIMAL(11,4),
    PRIMARY KEY (measurementID)
);

CREATE TABLE Ingredient (
    ingredientID int NOT NULL AUTO_INCREMENT,
    ingredientName varchar(20),
    measurementGroupID int,
    caloriesPerGram DECIMAL(11,3),
    costPerGram DECIMAL(11,3),
    FOREIGN KEY (measurementGroupID) REFERENCES MeasurementGroup(measurementGroupID),
    PRIMARY KEY (ingredientID)
);

CREATE TABLE RecipeIngredientMeasurements (
    recipeID int NOT NULL,
    ingredientID int NOT NULL,
    measurementID int NOT NULL,
    quantity dec(11,2),
    FOREIGN KEY (ingredientID) REFERENCES Ingredient(ingredientID),
    FOREIGN KEY (recipeID) REFERENCES Recipe(recipeID),
    FOREIGN KEY (measurementID) REFERENCES Measurement(measurementID),
    PRIMARY KEY (recipeID, ingredientID)
);

CREATE TABLE MeasurementGroupContents (
    measurementGroupID int NOT NULL,
    measurementID int NOT NULL,
    FOREIGN KEY (measurementID) REFERENCES Measurement(measurementID),
    FOREIGN KEY (measurementGroupID) REFERENCES MeasurementGroup(measurementGroupID),
    PRIMARY KEY (measurementGroupID, measurementID)
);

--INSERT INTO MeasurementGroup (measurementGroupName) VALUES ()
--INSERT INTO Measurement (measurementName, weightInGrams) VALUES ()
--INSERT INTO Ingredient (ingredientName, measurementGroupID, caloriesPerGram, costPerGram) VALUES ()
--INSERT INTO MeasurementGroupContents (measurementGroupID, measurementID) VALUES ()